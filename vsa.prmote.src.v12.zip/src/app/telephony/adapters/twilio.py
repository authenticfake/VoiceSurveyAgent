"""
Deprecated compatibility module.

Source-of-truth for Twilio adapter is:
    app.telephony.twilio_adapter.TwilioAdapter
"""
from app.telephony.twilio_adapter import TwilioAdapter

__all__ = ["TwilioAdapter"]