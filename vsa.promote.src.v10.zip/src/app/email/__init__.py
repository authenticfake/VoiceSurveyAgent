"""Email package (minimal for template FK resolution in tests)."""
