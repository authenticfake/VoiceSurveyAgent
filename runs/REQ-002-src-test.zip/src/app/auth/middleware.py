"""
Authentication middleware for FastAPI.

REQ-002: OIDC authentication integration
"""

from typing import Annotated
import inspect

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.auth.jwt import JWTService
from app.auth.schemas import TokenPayload
from app.shared.exceptions import InvalidTokenError, TokenExpiredError
from app.shared.logging import correlation_id_var, get_logger
from datetime import datetime
from uuid import UUID, NAMESPACE_URL, uuid5

from pydantic import BaseModel, Field

logger = get_logger(__name__)

# HTTP Bearer security scheme
security = HTTPBearer(auto_error=False)


class AuthMiddleware:
    """Middleware for JWT authentication."""

    def __init__(self) -> None:
        """Initialize auth middleware."""
        self._jwt_service = JWTService()

    async def __call__(
        self,
        request: Request,
        credentials: HTTPAuthorizationCredentials | None = Depends(security),
    ) -> TokenPayload:
        """Validate JWT token from Authorization header."""
        if credentials is None:
            logger.warning(
                "Missing authorization header",
                extra={"path": request.url.path},
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "MISSING_TOKEN",
                    "message": "Authorization header required",
                },
                headers={"WWW-Authenticate": "Bearer"},
            )

        try:
            payload = self._jwt_service.verify_token(credentials.credentials)

            if payload.type != "access":
                raise InvalidTokenError(message="Invalid token type")

            # Set correlation context for logging
            if payload.user_id:
                correlation_id_var.set(str(payload.user_id))

            return payload

        except TokenExpiredError:
            logger.warning(
                "Token expired",
                extra={"path": request.url.path},
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "TOKEN_EXPIRED",
                    "message": "Token has expired",
                },
                headers={"WWW-Authenticate": "Bearer"},
            )

        except InvalidTokenError as e:
            logger.warning(
                "Invalid token",
                extra={"path": request.url.path, "error": e.message},
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "INVALID_TOKEN",
                    "message": e.message,
                },
                headers={"WWW-Authenticate": "Bearer"},
            )


class CurrentUser(BaseModel):
    """Current authenticated user information (RBAC-friendly)."""

    id: UUID = Field(..., description="User ID")
    oidc_sub: str = Field(..., description="OIDC subject identifier")
    email: str = Field(..., description="User email")
    name: str = Field(..., description="User display name")
    role: str = Field(..., description="User role")

    # Backward-compat for existing code that expects token-style fields
    user_id: UUID | None = Field(None, description="Internal user ID (compat)")
    sub: str | None = Field(None, description="JWT subject (compat)")
    exp: datetime | None = Field(None, description="JWT exp (compat)")
    iat: datetime | None = Field(None, description="JWT iat (compat)")
    type: str | None = Field(None, description="JWT type (compat)")


async def get_current_user(
    request: Request,
    credentials: Annotated[
        HTTPAuthorizationCredentials | None,
        Depends(security),
    ] = None,
) -> CurrentUser:
    """FastAPI dependency for authenticated routes."""
    middleware = AuthMiddleware()
    payload: TokenPayload = await middleware(request, credentials)

    # Determine a stable UUID for RBAC/user identity
    if payload.user_id is not None:
        user_uuid = payload.user_id
    else:
        try:
            user_uuid = UUID(payload.sub)
        except Exception:
            user_uuid = uuid5(NAMESPACE_URL, payload.sub)

    return CurrentUser(
        id=user_uuid,
        user_id=payload.user_id or user_uuid,
        oidc_sub=payload.sub,
        email=payload.email or "",
        name=payload.email or payload.sub,
        role=payload.role or "viewer",
        sub=payload.sub,
        exp=payload.exp,
        iat=payload.iat,
        type=payload.type,
    )


# --- ADD THIS WRAPPER (IMPORTANT FOR REQ-004 TEST PATCHING) ---
async def _get_current_user_dep(
    request: Request,
    credentials: Annotated[
        HTTPAuthorizationCredentials | None,
        Depends(security),
    ] = None,
) -> CurrentUser:
    """
    Wrapper dependency that resolves get_current_user at runtime.

    This makes unit tests that patch `app.auth.middleware.get_current_user`
    work reliably, because FastAPI will always call this wrapper, and the
    wrapper will pick up the patched function.
    """
    result = get_current_user(request, credentials)
    if inspect.isawaitable(result):
        return await result
    return result  # type: ignore[return-value]


# Type alias for dependency injection
CurrentUserDep = Annotated[CurrentUser, Depends(_get_current_user_dep)]
AuthenticatedUser = CurrentUser
AuthenticatedUserDep = CurrentUserDep
