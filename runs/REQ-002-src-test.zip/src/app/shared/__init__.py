"""
Shared utilities and infrastructure components.

REQ-002: OIDC authentication integration
"""