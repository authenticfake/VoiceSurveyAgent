"""
VoiceSurveyAgent Application Package

REQ-002: OIDC authentication integration
"""

__version__ = "0.1.0"

from pkgutil import extend_path

# Allow "app" to be spread across multiple PYTHONPATH entries (REQ-001/002/003/004)
__path__ = extend_path(__path__, __name__)

__version__ = "0.1.0"


from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
