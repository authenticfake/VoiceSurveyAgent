"""
Test package for REQ-002: OIDC authentication integration.
"""